package main

import (
	login "GoProject/Login"
	"GoProject/config"
	"GoProject/routes"
	"log"
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/gorilla/mux"
)

func main() {
	r := mux.NewRouter()
	routes.RegisterBookRoutes(r)
	http.Handle("/", r)
	log.Fatal(http.ListenAndServe("localhost:8090", r))
	config.Connect()

	// Register book routes
	routes.RegisterBookRoutes(r)
	// Apply authentication middleware to book routes
	authenticatedRouter := http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		// Check authentication here
		authenticated := isAuthenticated(req)
		if !authenticated {
			http.Error(w, "Unauthorized", http.StatusUnauthorized)
			return
		}
		r.ServeHTTP(w, req)
	})

	// Serve book routes
	http.Handle("/books", authenticatedRouter)
	// Initialize Gin router
	router := gin.Default()
	// Routes
	router.GET("/", func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{"message": "Welcome to the login/signup page"})
	})

	// 	router.POST("/login", HandleLogin)
	// router.POST("/signup", HandleSignup)

	router.HandleFunc("/login", login.LoginHandler).Methods("POST")
	router.HandleFunc("/protected", login.ProtectedHandler).Methods("GET")
	// Run the server
	router.Run(":8080")
}

// Dummy authentication function
func isAuthenticated(req *http.Request) bool {
	// Implement your authentication logic here
	// For example, check if the user is logged in
	// This is just a dummy implementation
	// Replace it with your actual authentication logic
	return true
}
