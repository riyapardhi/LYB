package routes

import (
	"GoProject/controllers"
	"log"
	"net/http"

	"github.com/gorilla/mux"
)

func RegisterReaderRoutes(router *mux.Router) {
	router.HandleFunc("/api/reader", controllers.GetReaders).Methods("GET")
	//router.HandleFunc("/api/{BookId}", controllers.GetBookById).Methods("GET")
	router.HandleFunc("/api/reader", controllers.CreateReader).Methods("POST")
	router.HandleFunc("/api/{readerid}", controllers.UpdateReader).Methods("PUT")
	router.HandleFunc("/api/{readerid}", controllers.DeleteReader).Methods("DELETE")

	log.Fatal(http.ListenAndServe(":8080", router))
}
