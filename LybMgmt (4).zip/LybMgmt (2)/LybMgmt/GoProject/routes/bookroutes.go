package routes

import (
	"GoProject/controllers"
	login "GoProject/login"
	"log"
	"net/http"

	"github.com/gorilla/mux"
)

func RegisterBookRoutes(router *mux.Router) {
	router.HandleFunc("/api/book", controllers.GetBooks).Methods("GET")
	router.HandleFunc("/api/{BookId}", controllers.GetBookById).Methods("GET")
	router.HandleFunc("/api/book", controllers.CreateBook).Methods("POST")
	router.HandleFunc("/api/{BookId}", controllers.UpdateBook).Methods("PUT")
	router.HandleFunc("/api/{BookId}", controllers.DeleteBook).Methods("DELETE")

	router.HandleFunc("/login", login.LoginHandler).Methods("POST")
	router.HandleFunc("/protected", login.ProtectedHandler).Methods("GET")

	log.Fatal(http.ListenAndServe(":8090", router))
}
