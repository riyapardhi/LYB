package config

import (
	"fmt"

	"golang.org/x/crypto/bcrypt"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

var db *gorm.DB

func Connect() {

	dsn := "host=localhost user=postgres password=R!y@ dbname=postgres port=5432 sslmode=disable TimeZone=Asia/Shanghai"
	d, err := gorm.Open(postgres.Open(dsn), &gorm.Config{})
	if err != nil {
		panic(err)
	} else {
		fmt.Println("Succesfully connected")
	}
	db = d

}

func GetDB() *gorm.DB {
	return db

}

// User model
type User struct {
	gorm.Model
	Username     string `gorm:"unique;not null"`
	PasswordHash string `gorm:"not null"`
}

// MigrateDB migrates the database schema
func MigrateDB(db *gorm.DB) error {
	err := db.AutoMigrate(&User{})
	return err
}

// SetDBInstance sets the global database instance
func SetDBInstance(database *gorm.DB) {
	db = database
}

// GetUserByUsername retrieves a user by username
func GetUserByUsername(username string) (*User, error) {
	var user User
	err := db.Where("username = ?", username).First(&user).Error
	return &user, err
}

// CreateUser creates a new user in the database
func CreateUser(user *User, password string) error {
	// Hash the password
	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		return err
	}
	// Store the hashed password in the user struct
	user.PasswordHash = string(hashedPassword)
	// Create the user in the database
	err = db.Create(user).Error
	return err
}

// VerifyPassword verifies the user's password
func VerifyPassword(user *User, password string) bool {
	// Compare the hashed password with the plain-text password
	err := bcrypt.CompareHashAndPassword([]byte(user.PasswordHash), []byte(password))
	return err == nil
}
