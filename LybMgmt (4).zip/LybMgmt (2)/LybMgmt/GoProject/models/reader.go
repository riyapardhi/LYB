package models

import (
	"GoProject/config"
	"fmt"

	validator "gopkg.in/go-playground/validator.v8"
	"gorm.io/gorm"
)

var db1 *gorm.DB //var db *gorm.DB

type Reader struct {
	// gorm.Model
	RegisterNo int    `json:"registerno" validate:"required" gorm:"primarykey"`
	FullName   string `json:"fullname" validate:"required"`

	DOB         string `json:"dob" validate:"required"`
	EmailID     string `json:"emailid" validate:"required"`
	Mobile      int    `json:"mobile" validate:"required"`
	Gender      string `json:"gender" validate:"required"`
	Address     string `json:"address" validate:"required"`
	Subcription string `json:"subcription" validate:"required"`
	SubDuration int    `json:"subduration" validate:"required"`
	SubCost     int    `json:"subcost" validate:"required"`
	// Id          string `json:"id" validate:"required" gorm:"primarykey"`
	// Name        string `json:"name" validate:"required"`
	// Isbn        string `json:"isbn" validate:"required"`
	// Author      string `json:"author" validate:"required"`
	// Discription string `json:"discription" validate:"required"`
	// IssueDate   string `json:"issuedate" validate:"required"`
	// DueDate     string `json:"duedate" validate:"required"`
}

func ValidateReader(reader *Reader) error {
	validate := validator.New(&validator.Config{TagName: "validate"})

	if err := validate.Struct(reader); err != nil {
		return err
	}
	return nil
}

func init() {
	config.Connect()
	db1 = config.GetDB()
	db1.AutoMigrate(&Book{})
}

func (r *Reader) CreateReader() *Reader {
	// db1.NewRecord(b)
	db1.Create(&r)
	return r
}

func GetAllReaders() []Reader {
	var Readers []Reader
	db1.Find(&Readers)
	fmt.Println(&Readers)
	return Readers
}

// func GetReaderByRN(RegisterNo int64) (*Reader, *gorm.DB) {
// 	var getReader Reader
// 	getReader.RegisterNo = strconv.FormatInt(RegisterNo, )
// 	db1 := db1.Where(&getReader).Find(&getReader)

// 	return &getReader, db1
// }

func DeleteReader(ID int64) Reader {
	var reader Reader
	db1.Where("RegisterNo=?", ID).Delete(reader)
	return reader
}
