package controllers

import (
	"GoProject/models"
	"GoProject/utils"
	"encoding/json"
	"fmt"
	"net/http"
	"strconv"

	"github.com/gorilla/mux"
)

var NewReader models.Book

func GetReaders(w http.ResponseWriter, r *http.Request) {
	newBooks := models.GetAllReaders()
	res, _ := json.Marshal(newBooks)
	w.WriteHeader(http.StatusOK)
	w.Write(res)

}

func GetBReaderByRegisterNo(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	bookId := vars["BookId"]
	ID, err := strconv.ParseInt(bookId, 0, 0)
	if err != nil {
		fmt.Println("Error While Parsing")

	}
	newBook, _ := models.GetBookById(ID)
	res, _ := json.Marshal(newBook)
	w.WriteHeader(http.StatusOK)
	w.Write(res)

}

func CreateReader(w http.ResponseWriter, r *http.Request) {
	createreader := &models.Book{}
	utils.ParseBody(r, createreader)
	b := createreader.CreateBook()
	res, _ := json.Marshal(b)
	w.WriteHeader(http.StatusOK)
	w.Write(res)

}

func DeleteReader(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	ReaderId := vars["ReaderId"]
	ID, err := strconv.ParseInt(ReaderId, 0, 0)
	if err != nil {
		fmt.Println("Error While Parsing")

	}
	models.DeleteBook(ID)
	w.WriteHeader(http.StatusOK)

}

func UpdateReader(w http.ResponseWriter, r *http.Request) {
	var UpdateReader = &models.Book{}
	utils.ParseBody(r, UpdateBook)
	vars := mux.Vars(r)
	ReaderId := vars["ReaderId"]
	ID, err := strconv.ParseInt(ReaderId, 0, 0)
	if err != nil {
		fmt.Println("Error while Parsing")
	}
	readerdetails, db := models.GetBookById(ID)

	if UpdateReader.Name != "" {
		readerdetails.Name = UpdateReader.Name
	}

	if UpdateReader.Author != "" {
		readerdetails.Author = UpdateReader.Author
	}

	Db1 := db.Save(&readerdetails)

	res, _ := json.Marshal(Db1)
	w.WriteHeader(http.StatusOK)
	w.Write(res)

}
