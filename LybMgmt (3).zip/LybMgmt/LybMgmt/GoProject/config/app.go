package config

import (
//	"fmt"

	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

var db *gorm.DB

// func Connect() {

// 	dsn := "host=localhost user=postgres password=R!y@ dbname=postgres port=5432 sslmode=disable TimeZone=Asia/Shanghai"
// 	d, err := gorm.Open(postgres.Open(dsn), &gorm.Config{})
// 	if err != nil {
// 		panic(err)
// 	} else {
// 		fmt.Println("Succesfully connected")
// 	}
// 	db = d

// }

// func GetDB() *gorm.DB {
// 	return db

// }


// User model
type User struct {
	ID       uint   `gorm:"primaryKey"`
	Username string `gorm:"unique"`
	Password string
 }
 // InitializeDatabase initializes the database connection
 func InitializeDatabase(connectionString string) error {
	var err error
	db, err = gorm.Open(postgres.Open(connectionString), &gorm.Config{})
	if err != nil {
		return err
	}
	// Auto-migrate the User model
	db.AutoMigrate(&User{})
	return nil
 }
 // CloseDatabase closes the database connection
 func CloseDatabase() {
	db.Close()
 }
 // Check if the username and password combination is valid
 func IsValidUser(username, password string) (bool, error) {
	var user User
	if err := db.Where("username = ?", username).First(&user).Error; err != nil {
		return false, err
	}
	// Compare stored password with the provided password (using bcrypt or any other secure method)
	// Example:
	// return bcrypt.CompareHashAndPassword([]byte(user.Password), []byte(password)) == nil
	return user.Password == password, nil
 }
 // Check if the username is available for signup
 func IsUsernameAvailable(username string) (bool, error) {
	var count int64
	if err := db.Model(&User{}).Where("username = ?", username).Count(&count).Error; err != nil {
		return false, err
	}
	return count == 0, nil
 }
 
