package models

import (
	//"GoProject/config"
	"fmt"
	"strconv"

	validator "gopkg.in/go-playground/validator.v8"

	"gorm.io/gorm"
)

var db *gorm.DB

type Book struct {
	// gorm.Model
	Id          string `json:"id" validate:"required" gorm:"primarykey"`
	Name        string `json:"name" validate:"required"`
	Isbn        string `json:"isbn" validate:"required"`
	Author      string `json:"author" validate:"required"`
	Discription string `json:"discription" validate:"required"`
	IssueDate   string `json:"issuedate" validate:"required"`
	DueDate     string `json:"duedate" validate:"required"`
}

func ValidateBook(book *Book) error {
	validate := validator.New(&validator.Config{TagName: "validate"})

	if err := validate.Struct(book); err != nil {
		return err
	}
	return nil
}

func init() {
	// config.Connect()
	// db = config.GetDB()
	// db.AutoMigrate(&Book{})
}

func (b *Book) CreateBook() *Book {
	// db.NewRecord(b)
	db.Create(&b)
	return b
}

func GetAllBooks() []Book {
	var Books []Book
	db.Find(&Books)
	fmt.Println(&Books)
	return Books
}

func GetBookById(Id int64) (*Book, *gorm.DB) {
	var getBook Book
	getBook.Id = strconv.FormatInt(Id, 10)
	db := db.Where(&getBook).Find(&getBook)

	return &getBook, db
}

func DeleteBook(ID int64) Book {
	var book Book
	db.Where("ID=?", ID).Delete(book)
	return book
}
