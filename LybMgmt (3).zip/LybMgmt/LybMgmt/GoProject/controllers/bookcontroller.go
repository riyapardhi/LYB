package controllers

import (
	"GoProject/models"
	"GoProject/utils"
	"encoding/json"
	"fmt"
	"net/http"
	"strconv"

	"github.com/gorilla/mux"
)

var NewBook models.Book

func GetBooks(w http.ResponseWriter, r *http.Request) {
	newBooks := models.GetAllBooks()
	res, _ := json.Marshal(newBooks)
	w.WriteHeader(http.StatusOK)
	w.Write(res)

}

func GetBookById(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	bookId := vars["BookId"]
	ID, err := strconv.ParseInt(bookId, 0, 0)
	if err != nil {
		fmt.Println("Error While Parsing")

	}
	newBook, _ := models.GetBookById(ID)
	res, _ := json.Marshal(newBook)
	w.WriteHeader(http.StatusOK)
	w.Write(res)

}

func CreateBook(w http.ResponseWriter, r *http.Request) {
	createbook := &models.Book{}
	utils.ParseBody(r, createbook)
	b := createbook.CreateBook()
	res, _ := json.Marshal(b)
	w.WriteHeader(http.StatusOK)
	w.Write(res)

}

func DeleteBook(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	bookId := vars["BookId"]
	ID, err := strconv.ParseInt(bookId, 0, 0)
	if err != nil {
		fmt.Println("Error While Parsing")

	}
	models.DeleteBook(ID)
	w.WriteHeader(http.StatusOK)

}

func UpdateBook(w http.ResponseWriter, r *http.Request) {
	var UpdateBook = &models.Book{}
	utils.ParseBody(r, UpdateBook)
	vars := mux.Vars(r)
	bookId := vars["bookId"]
	ID, err := strconv.ParseInt(bookId, 0, 0)
	if err != nil {
		fmt.Println("Error while Parsing")
	}
	bookdetails, db := models.GetBookById(ID)

	if UpdateBook.Name != "" {
		bookdetails.Name = UpdateBook.Name
	}

	if UpdateBook.Author != "" {
		bookdetails.Author = UpdateBook.Author
	}

	Db := db.Save(&bookdetails)

	res, _ := json.Marshal(Db)
	w.WriteHeader(http.StatusOK)
	w.Write(res)

}
