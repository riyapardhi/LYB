package auth

import (
	"net/http"

	"github.com/gin-gonic/gin"
)

// Handle login logic
func HandleLogin(c *gin.Context) {
	// Retrieve username and password from request
	username := c.PostForm("username")
	password := c.PostForm("password")
	// Validate username and password
	isValid, err := IsValidUser(username, password)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Internal server error"})
		return
	}
	if isValid {
		// Successful login
		c.JSON(http.StatusOK, gin.H{"message": "Login successful"})
	} else {
		// Invalid credentials
		c.JSON(http.StatusUnauthorized, gin.H{"error": "Invalid username or password"})
	}
}

// Handle signup logic
func HandleSignup(c *gin.Context) {
	// Retrieve username and password from request
	username := c.PostForm("username")
	password := c.PostForm("password")
	// Check if the username is available
	isAvailable, err := IsUsernameAvailable(username)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Internal server error"})
		return
	}
	if isAvailable {
		// Perform signup
		// Here you would typically add the user to the database
		c.JSON(http.StatusCreated, gin.H{"message": "Signup successful"})
	} else {
		// Username already exists
		c.JSON(http.StatusBadRequest, gin.H{"error": "Username already exists"})
	}
}
