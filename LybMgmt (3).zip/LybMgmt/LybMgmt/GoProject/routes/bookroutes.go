package routes

import (
	"GoProject/controllers"
	"log"
	"net/http"

	"github.com/gorilla/mux"
)

func RegisterBookRoutes(router *mux.Router) {
	router.HandleFunc("/api/book", controllers.GetBooks).Methods("GET")
	router.HandleFunc("/api/{BookId}", controllers.GetBookById).Methods("GET")
	router.HandleFunc("/api/book", controllers.CreateBook).Methods("POST")
	router.HandleFunc("/api/{BookId}", controllers.UpdateBook).Methods("PUT")
	router.HandleFunc("/api/{BookId}", controllers.DeleteBook).Methods("DELETE")
	

	log.Fatal(http.ListenAndServe(":8080", router))
}
