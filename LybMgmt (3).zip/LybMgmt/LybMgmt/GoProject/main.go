package main

import (
	"GoProject/routes"
	"log"
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/gorilla/mux"
)

func main() {
	r := mux.NewRouter()
	routes.RegisterBookRoutes(r)
	http.Handle("/", r)
	log.Fatal(http.ListenAndServe("localhost:8080", r))
	//config.Connect()
	// Initialize the database
	
	// Initialize Gin router
	router := gin.Default()
	// Routes
	router.GET("/", func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{"message": "Welcome to the login/signup page"})
	})
	router.POST("/login", HandleLogin)
	router.POST("/signup", HandleSignup)
	// Run the server
	router.Run(":8080")

}
